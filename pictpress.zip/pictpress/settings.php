<?php
require_once(dirname(__FILE__) . "/../../../wp-config.php");

$pp_thumbs_per_row = get_settings('pp_thumbs_per_row');
$pp_max_thumbs     = get_settings('pp_max_thumbs');
$pp_more_thumbs    = get_settings('pp_more_thumbs');
$pp_use_css        = get_settings('pp_use_css');

?>
